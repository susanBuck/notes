All files are � 2008-2009 by Harald Kirschner and available under the [MIT License](http://www.opensource.org/licenses/mit-license.php).

Package version of http://digitarald.de/project/fancyupload/3-0/showcase/photoqueue/

* Give write access to server/script.log
* Open http://localhost/build.html or wherever your.
* Edit server/script.php to validate and move the files wherever you want to.
* Visit http://digitarald.de for updates